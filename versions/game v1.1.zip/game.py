from textwrap import wrap
import os
import time
#import click
import keyboard

#file=input("Enter Name of Map File: ")
#if file == "":
#	file = "map.txt"
#if file[4:] != ".txt":
#	file+=".txt"
#os.system("cls")
os.system("mode 35, 22")

title="titles\\title.txt"
t = open(title, "r")
tl = t.readlines()
title=""
for l in tl:
    title+=l
print(title)

input("")
os.system("cls")

level=1


first=True

spikes=[]
flames=[]
snakes=[]

pos=[0,0]

cam=[0,0,15,15]

map=[]

def getLevel(Level):
        file="levels\level"+str(Level)+".txt"
        global first
        global spikes
        global flames
        global snakes
        global pos
        global cam
        global map
        spikes=[]
        flames=[]
        snakes=[]
        pos=[0,0]
        cam=[0,0,15,15]
        map=[]
        fill=""
        for x in range(cam[2]):
            fill+="/"
        maxmap=0

        f = open(file, "r")
        l = f.readlines()
        i=0
        map=[]
        for x in l:
            i+=1
            if i!=len(l):
                x=x[:-1]
            #print(x)
            x=wrap(x+fill,1)
            map.append(x)
            if maxmap <= len(x):
                maxmap=len(x)
        fill2=[]
        for x in range(maxmap):
            fill2.append("/")
        for x in range(cam[3]):
            map.append(fill2)
        #print(map)
        for y in range(len(map)):
            for x in range(len(map[y])):
                if map[y][x] == '^' or map[y][x] == ',':
                    spikes.append([x,y])
                if map[y][x] == '=':
                    flames.append([x,y])
                if map[y][x] == '$':
                    snakes.append([x,y])
                #if map[y][x] == '/':
                    #map[y][x]=" "
                if map[y][x] == '@':
                    if map[y+1][x] == "#":
                        map[y][x]="_"
                    else:
                        map[y][x]="."
                    pos=[x,y]
                if map[y][x] == '-' or map[y][x] == '~' or map[y][x] == ';':
                    if map[y+1][x] == "#":
                        map[y][x]="_"
                    else:
                        map[y][x]="."
        cam[0]=pos[0]-int(cam[2]/2)
        cam[1]=pos[1]-int(cam[3]/2)   
getLevel(level)

#print(map)
#print(len(map))
loops=0
dir=1
      
move=[0,0]
delay=0
looped=0
while True:
    delay+=1
    if delay>= 10 and move[0]!=0 or delay>= 10 and move[1]!=0 or first==True:
        looped+=1
        os.system("cls")
        for s in spikes:
            if looped%4 == 0:
                map[s[1]][s[0]]="^"
            elif looped%4 == 2:
                map[s[1]][s[0]]=","

        for f in flames:
            for d in range(3):
                if looped%8 >= 0 and looped%8 <= 3:
                    if (d+(looped%2))%2==0:
                        if map[f[1]][f[0]+1]=="#":
                            map[f[1]][f[0]-d-1]="~"
                        if map[f[1]][f[0]-1]=="#":
                            map[f[1]][f[0]+d+1]="~"
                            
                    else:
                        if map[f[1]][f[0]+1]=="#":
                            map[f[1]][f[0]-d-1]="-"
                        if map[f[1]][f[0]-1]=="#":
                            map[f[1]][f[0]+d+1]="-"
                elif looped%8==4:
                    if map[f[1]][f[0]+1]=="#":
                        map[f[1]][f[0]-d-1]="."
                    if map[f[1]][f[0]-1]=="#":
                        map[f[1]][f[0]+d+1]="."
                elif looped%8==7:
                    if map[f[1]][f[0]+1]=="#":
                        map[f[1]][f[0]-1]=";"
                    if map[f[1]][f[0]-1]=="#":
                        map[f[1]][f[0]+1]=";"
        
        for n in range(len(snakes)):
            sPastPos=[]
            if map[snakes[n][1]+1][snakes[n][0]]==":":
                map[snakes[n][1]+1][snakes[n][0]]="$"
                map[snakes[n][1]][snakes[n][0]]="%"
                snakes[n]=[snakes[n][0],snakes[n][1]+1]
            elif map[snakes[n][1]][snakes[n][0]+1]==":":
                map[snakes[n][1]][snakes[n][0]+1]="$"
                map[snakes[n][1]][snakes[n][0]]="%"
                snakes[n]=[snakes[n][0]+1,snakes[n][1]]
            elif map[snakes[n][1]-1][snakes[n][0]]==":":
                map[snakes[n][1]-1][snakes[n][0]]="$"
                map[snakes[n][1]][snakes[n][0]]="%"
                snakes[n]=[snakes[n][0],snakes[n][1]-1]
            elif map[snakes[n][1]][snakes[n][0]-1]==":":
                map[snakes[n][1]][snakes[n][0]-1]="$"
                map[snakes[n][1]][snakes[n][0]]="%"
                snakes[n]=[snakes[n][0]-1,snakes[n][1]]
            sEndPos=[snakes[n][0],snakes[n][1]]  
            found=False
            while found==False:
                sPastPos.append(sEndPos)
                #print(sPastPos)
                if not [sEndPos[0],sEndPos[1]+1] in sPastPos and map[sEndPos[1]+1][sEndPos[0]]=="%":
                    sEndPos=[sEndPos[0],sEndPos[1]+1]
                    #print("1")
                elif not [sEndPos[0]+1,sEndPos[1]] in sPastPos and map[sEndPos[1]][sEndPos[0]+1]=="%":
                    sEndPos=[sEndPos[0]+1,sEndPos[1]]
                    #print("2")
                elif not [sEndPos[0],sEndPos[1]-1] in sPastPos and map[sEndPos[1]-1][sEndPos[0]]=="%":
                    sEndPos=[sEndPos[0],sEndPos[1]-1]
                    #print("3")
                elif not [sEndPos[0]-1,sEndPos[1]] in sPastPos and map[sEndPos[1]][sEndPos[0]-1]=="%":
                    sEndPos=[sEndPos[0]-1,sEndPos[1]]
                    #print("4")
                else:
                    #print(sEndPos)
                    #print(map[sEndPos[1]][sEndPos[0]])
                    map[sEndPos[1]][sEndPos[0]]=":"
                    found=True
                    
            first=False
        delay=0
        #if dir==1 and pos[1]>=len(map)-1:
        #  dir=-1
        #elif dir==-1 and pos[1]==0:
        #  dir=1
        #pos[1]+=dir
        tileH = map[pos[1]][pos[0]+move[0]]
        if not tileH == "#" and not tileH == "=" and not tileH == "T":
            pos[0] += move[0]
        tileV = map[pos[1]+move[1]][pos[0]]
        if not tileV == "#" and not tileH == "=" and not tileH == "T":
            pos[1] += move[1]
        cam[0]=pos[0]-int(cam[2]/2)
        cam[1]=pos[1]-int(cam[3]/2)
        tile = map[pos[1]][pos[0]]
        if tile == "^" or tile == "~" or tile == "-" or tile == "$" or tile == "%":
            os.system("cls")
            title="titles\\gameOver.txt"
            t = open(title, "r")
            tl = t.readlines()
            title=""
            for l in tl:
                title+=l
            print(title)
            input("")    
            level=1
            os.system("cls")
            getLevel(level)
        if tile == "*":
            os.system("cls")
            title="titles\\nextLevel.txt"
            t = open(title, "r")
            tl = t.readlines()
            title=""
            for l in tl:
                title+=l
            print(title)
            input("")    
            os.system("cls")
            level+=1
            getLevel(level)
        signPos=[0,0]
        if map[pos[1]+1][pos[0]] == "T":
            signPos=[pos[1]+1,pos[0]]
        if map[pos[1]][pos[0]+1] == "T":
            signPos=[pos[1],pos[0]+1]
        if map[pos[1]-1][pos[0]] == "T":
            signPos=[pos[1]-1,pos[0]]
        if map[pos[1]][pos[0]-1] == "T":
            signPos=[pos[1],pos[0]-1]
        if map[pos[1]][pos[0]] == "T":
            signPos=[pos[1],pos[0]]
        if signPos!=[0,0]:
            textFile="levels\\text\\level"+str(level)+"-text-"+str(signPos[1])+"-"+str(signPos[0])+".txt"
            sign = open(textFile, "r")
            signText = sign.read()
        else:
            signText=""
        move=[0,0]
        reset=map[pos[1]][pos[0]]
        map[pos[1]][pos[0]]="@"
        pm=[]
        if len(map)-cam[1]-1 < cam[3]:
            height=len(map)
        else:
            height=cam[3]
        for iy in range(height):
            y=map[iy+cam[1]]
            py=""
            if len(y)-cam[0]-1 < cam[2]:
                width=len(y)-cam[0]-1
            else:
                width=cam[2]
            for ix in range(width):
                x=y[ix+cam[0]]
                if x=="/":
                    py+="  "
                elif x==":":
                    py+=". "
                elif x=="$":
                    py+="S "
                elif x=="%":
                    py+="s "
                else:
                    py+=x+" "
                
            pm.append(py)
            #click.clear()
        screen=""
        #print("  _______________________________")
        screen+="  _______________________________\n"
        for p in pm:
            #print(" | "+p+"| ")
            screen+=" | "+p+"| \n"
        #print(" |_______________________________|")
        screen+=" |_______________________________|"
        print(screen)
        print(signText)
        map[pos[1]][pos[0]]=reset

    if delay>= 10 and keyboard.is_pressed("w"):
        move[1]=-1
    if delay>= 10 and keyboard.is_pressed("s"):
        move[1]=1
    if delay>= 10 and keyboard.is_pressed("a"):
        move[0]=-1
    if delay>= 10 and keyboard.is_pressed("d"):
        move[0]=1
    if delay>= 10 and keyboard.is_pressed("esc"):
##        save=[]
##        map[pos[1]][pos[0]]="@"
##        for ys in range(len(map)-cam[3]):
##            line=""
##            for xs in range(len(map[ys])-cam[2]):
##                line+=map[ys][xs]+" "
##            save.append(line)
##        s=open("map2.txt", "w")
##        for x in save:
##            #print(x)
##            s.write(x+"\n")
##        s.close()
##        #os.system("start "+"map2.txt")
        exit()
        
    time.sleep(0.01)
    loops+=1
            

