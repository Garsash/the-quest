import keyboard

keyboard.wait('up arrow')
print("aa")
