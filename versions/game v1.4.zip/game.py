from textwrap import wrap
import os
import time
#import click
import keyboard
from rcolors import colors
import random

#camera set up
cam=[0,0,15,15]
os.system("mode "+ str(cam[2]*2+5)+", "+str(cam[3]+9))

#get title card from files
def getTitle(name):
    #open and read
    title="titles\\"+name+".txt"
    titleFile = open(title, "r")
    titleLines = titleFile.readlines()
    title=""
    #loop and assign colours
    for lines in titleLines:
        line=""
        for character in lines:
            if character == "y":
                line+="\033[1;33;40m"
            elif character == "w":
                line+="\033[1;37;40m"
            elif character == "%":
                line+="\033[1;31;40m"
            elif character == "p":
                line+="\033[1;35;40m"
            else:
                line+=character
        title+=line
    return title

#define player object
class Player():
    def __init__(self,xPos,yPos):
        self.x = xPos
        self.y = yPos
        self.attacking=False

#define spike object
class Spike():
    def __init__(self,xPos,yPos,State,Timer):
        self.x = xPos
        self.y = yPos
        self.state = State
        self.maxTime = Timer
        self.time = 0

#define flamethrower object
class Flamethrower():
    def __init__(self,xPos,yPos,Stage,Facing,Range,Timer):
        self.x = xPos
        self.y = yPos
        self.stage = Stage
        self.facing = Facing
        self.range= Range
        self.maxTime = Timer
        self.time = 0

#define snake object
class Snake():
    def __init__(self,xPos,yPos,Segments):
        self.x = xPos
        self.y = yPos
        self.segments = Segments

#define snake segment object
class Segment():
    def __init__(self,xPos,yPos):
        self.x = xPos
        self.y = yPos

#define enemy object
class Enemy():
    def __init__(self,xPos,yPos):
        self.x = xPos
        self.y = yPos
        self.here = "."

#define box object
class Box():
    def __init__(self,xPos,yPos):
        self.x = xPos
        self.y = yPos
        self.here = "."

#define button object
class Button():
    def __init__(self,xPos,yPos,Doors,Wires):
        self.x = xPos
        self.y = yPos
        self.state = False
        self.doors = Doors
        self.wires=Wires

#define switch object
class Switch():
    def __init__(self,xPos,yPos,Doors,Wires):
        self.x = xPos
        self.y = yPos
        self.state = False
        self.doors = Doors
        self.wires=Wires

#define door object
class Door():
    def __init__(self,xPos,yPos):
        self.x = xPos
        self.y = yPos

#display opening title card
print(getTitle("title"))

#get level skip input
cheat=input("")
os.system("cls")

#try to skip levels
try:
    int(cheat)
except:
    cheat=1

level=cheat

first=True

#create global object arrays
spikes=[]
flames=[]
snakes=[]
enemies=[]
boxes=[]
buttons=[]
switches=[]
neighbors=[[-1,0],[0,-1],[1,0],[0,1]]

#create player
player=Player(0,0)

map=[]

#define get level function
def getLevel(Level):

        #get and reset global variables
        global first, spikes, flames, snakes, enemies, cam, map, player, boxes, buttons, switches
        spikes=[]
        flames=[]
        snakes=[]
        enemies=[]
        boxes=[]
        buttons=[]
        switches=[]
        cam=[0,0,15,15]
        player=Player(0,0)
        map=[]
        
        fill=""
        for x in range(cam[2]):
            fill+="/"
		
        #open level file
        file="levels\level"+str(Level)+".txt"
        file = open(file, "r")
        lines = file.readlines()

        i=0
        #reset map
        map=[]

        #set up file format
        maxmap=0
        for line in lines:
            i+=1
            if i!=len(lines):
                line=line[:-1]
            #print(x)
            line=wrap(line+fill,1)
            map.append(line)
            if maxmap <= len(line):
                maxmap=len(line)

        fill2=[]
        for x in range(maxmap):
            fill2.append("/")
        for x in range(cam[3]):
            map.append(fill2)

        #loop through map
        for y in range(len(map)):
            for x in range(len(map[y])):
                #find and create spikes
                if map[y][x] == '^' or map[y][x] == ',':
                    spikes.append(Spike(x,y,0,3))
                if map[y][x] == '^' or map[y][x] == '"':
                    spikes.append(Spike(x,y,0,7))

                #find and create flamethrowers
                elif map[y][x] == '=':
                    flameDir=0
                    if map[y][x-1] == "#":
                        flameDir=1
                    elif map[y][x+1] == "#":
                        flameDir=-1
                    else:
                        continue
                    flames.append(Flamethrower(x,y,0,flameDir,3,7))

                #find and create snakes
                elif map[y][x] == '$':
                    #find body parts
                    body=[Segment(x,y)]
                    for bit in body:
                        for neighbor in neighbors:
                            target=[neighbor[0]+bit.x,neighbor[1]+bit.y]
                            if any(part.x==target[0] and part.y==target[1] for part in body):
                                continue
                            if map[target[1]][target[0]] == "%":
                                body.append(Segment(target[0],target[1]))
                    body.pop(0)
                    snakes.append(Snake(x,y,body))

                #find and create enemies
                elif map[y][x] == 'E':
                    enemies.append(Enemy(x,y))

                #find and create boxes
                elif map[y][x] == '&':
                    boxes.append(Box(x,y))

                #find and create buttons
                elif map[y][x] == 'p':
                    wires=[[x,y]]
                    doors=[]
                    #find wires
                    for wire in wires:
                        for neighbor in neighbors:
                            target=[neighbor[0]+wire[0],neighbor[1]+wire[1]]
                            if any(Wire[0]==target[0] and Wire[1]==target[1] for Wire in wires):
                                continue
                            if map[target[1]][target[0]] == "b":
                                wires.append([target[0],target[1]])
                            if map[target[1]][target[0]] == "D":
                                doors=[Door(target[0],target[1])]
                                #find doors
                                for door in doors:
                                    for meighbor in neighbors:
                                        Target=[meighbor[0]+door.x,meighbor[1]+door.y]
                                        if any(Door.x==Target[0] and Door.y==Target[1] for Door in doors):
                                            continue
                                        if map[Target[1]][Target[0]] == "D":
                                            doors.append(Door(Target[0],Target[1]))
                    wires.pop(0)
                    buttons.append(Button(x,y,doors,wires))

                #find and create switches
                elif map[y][x] == 'S':
                    wires=[[x,y]]
                    doors=[]
                    #find wires
                    for wire in wires:
                        for neighbor in neighbors:
                            target=[neighbor[0]+wire[0],neighbor[1]+wire[1]]
                            if any(Wire[0]==target[0] and Wire[1]==target[1] for Wire in wires):
                                continue
                            if map[target[1]][target[0]] == "b":
                                wires.append([target[0],target[1]])
                            if map[target[1]][target[0]] == "D":
                                doors=[Door(target[0],target[1])]
                                #find doors
                                for door in doors:
                                    for meighbor in neighbors:
                                        Target=[meighbor[0]+door.x,meighbor[1]+door.y]
                                        if any(Door.x==Target[0] and Door.y==Target[1] for Door in doors):
                                            continue
                                        if map[Target[1]][Target[0]] == "D":
                                            doors.append(Door(Target[0],Target[1]))
                    wires.pop(0)
                    switches.append(Switch(x,y,doors,wires))

                #find and move player
                elif map[y][x] == '@':
                    if map[y+1][x] == "#":
                        map[y][x]="_"
                    else:
                        map[y][x]="."
                    player.x=x
                    player.y=y

                #switch out animation shapes
                elif map[y][x] == '-' or map[y][x] == '~' or map[y][x] == ';':
                    if map[y+1][x] == "#":
                        map[y][x]="_"
                    else:
                        map[y][x]="."
                        
        #set camera position
        cam[0]=player.x-int(cam[2]/2)
        cam[1]=player.y-int(cam[3]/2) 
        save=[]

        #put player on map
        map[player.y][player.x]="@"

#get initial level
getLevel(level)

#set up variables
loops=0
dir=1
      
move=[0,0]
delay=0
looped=0
savePoint=[0,0]
out=[]

#gamer loop
while True:
    delay+=1
    #step frame if button press
    if delay>= 10 and move[0]!=0 or delay>= 10 and move[1]!=0 or first==True:
        out=[]
        delay=0
        saved=False
        first=False
        looped+=1
        
        #clear screen
        os.system("cls")

        #loop through spikes and change state
        for s in spikes:
            #up
            if s.time == 0:
                map[s.y][s.x]="^"
                s.state = 1
            #down
            elif s.time == 2:
                map[s.y][s.x]=","
                s.state = 0
            s.time+=1
            #reset
            if s.time > s.maxTime:
                s.time = 0

        #loop through flamethrowers and change state
        for f in flames:
            #loop range
            for d in range(f.range):
                #flames
                if f.time >= 0 and f.time <= 3:
                    if (d+(f.time%2))%2==0:
                        map[f.y][f.x+((d+1)*f.facing)]="~"
                    else:
                        map[f.y][f.x+((d+1)*f.facing)]="-"
                #reset
                elif f.time==4:
                    map[f.y][f.x+((d+1)*f.facing)]="."
                #warning
                elif f.time==7:
                    map[f.y][f.x+(1*f.facing)]=";"
            f.time+=1
            #reset
            if f.time > f.maxTime:
                f.time = 0

        #loop through snakes and move forward
        for n in snakes:
            #direction vecors
            forward=[n.x-n.segments[0].x,n.y-n.segments[0].y]
            left=[forward[1]*-1,forward[0]]
            right=[forward[1],forward[0]*-1]

            #find next space
            if map[n.y+forward[1]][n.x+forward[0]] == ":":
                nextPos=[n.x+forward[0],n.y+forward[1]]
            elif map[n.y+left[1]][n.x+left[0]]:
                nextPos=[n.x+left[0],n.y+left[1]]
            elif map[n.y+right[1]][n.x+right[0]]:
                nextPos=[n.x+right[0],n.y+right[1]]

            #delete end segment
            map[n.segments[-1].y][n.segments[-1].x]=":"
            n.segments.pop(-1)

            #add new segment
            map[n.y][n.x]="%"
            n.segments.insert(0,Segment(n.x,n.y))

            #move forward
            n.x=nextPos[0]
            n.y=nextPos[1]
            map[n.y][n.x]="$"

        #loop through enemies and move
        for enemy in enemies:
            #find distance from player
            distx=player.x-enemy.x
            disty=player.y-enemy.y
            target=[0,0]
            
            if abs(distx) <= 6 and abs(disty) <= 6:
                scentMap=[]
                
                #create scent map
                for y in range(13):
                    row=[]
                    for x in range(13):
                        row.append(26)
                    scentMap.append(row)

                #create searching map
                searching=[]
                for y in range(13):
                    row=[]
                    for x in range(13):
                        row.append(False)
                    searching.append(row)

                #set player location
                searching[6][6]=True
                scentMap[6][6]=0
                nodes=[[6,6]]

                #loop through nodes
                for n in nodes:
                    #look at neighbors
                    for x in neighbors:
                        #variable set up
                        nx=n[0]+x[0]
                        ny=n[1]+x[1]
                        hx=n[0]
                        hy=n[1]
                        worldy=player.y+ny-6
                        worldx=player.x+nx-6
                        
                        #if inside map
                        if ny < 0 or ny >= 13:
                            continue
                        if nx < 0 or nx >= 13:
                            continue

                        here=scentMap[hy][hx]
                        #if not searched already
                        if searching[ny][nx] == False:
                            #is there a wall
                            state=map[worldy][worldx]
                            if state=="#":
                                continue

                            #get smallest scent
                            if scentMap[ny][nx] >= here:
                                scentMap[ny][nx]=here+1
                                nodes.append([nx,ny])
                            searching[ny][nx]=True

                            #found enemy
                            if state=="E":
                                nodes=[]
                                lowest=26
                                target=[0,0]
                                values=[]

                                #look at neighbors
                                for y in neighbors:   
                                    ex=nx+y[0]
                                    ey=ny+y[1]
                                    if ey < 0 or ey >= 13:
                                        continue
                                    if ex < 0 or ex >= 13:
                                        continue
                                    #find values
                                    values.append([y[0],y[1],scentMap[ey][ex]])

                                #get smallest values
                                minV=24
                                for m in values:
                                    if m[2] < minV:
                                        minV=m[2]

                                #pick random closest direction
                                closest=[v for v in values if v[2]==minV]
                                if len(closest)>=1:
                                    choice=random.choice(closest)
                                    target=[choice[0],choice[1]]
                                break
            #move enemy
            map[enemy.y][enemy.x]=enemy.here
            enemy.x+=target[0]
            enemy.y+=target[1]
            enemy.here=map[enemy.y][enemy.x]
            map[enemy.y][enemy.x]="E"

        #if player moving box
        if map[player.y+move[1]][player.x+move[0]] == "&":
            #loop through boxes
            for b in boxes:
                #find correct box
                if b.x == player.x+move[0] and b.y == player.y+move[1]:
                    #move box
                    tileB=map[b.y+move[1]][b.x+move[0]]
                    if not tileB == "#" and not tileB == "=" and not tileB == "T" and not tileB == "/" and not tileB == "&":
                        map[b.y][b.x] = b.here
                        b.x+=move[0]
                        b.y+=move[1]
                        b.here=map[b.y][b.x]
                        map[b.y][b.x]="&"
                    else:
                        move=[0,0]
                        
        #loop through buttons and check          
        for b in buttons:
            #if pressed
            if any(box.x == b.x and box.y == b.y for box in boxes) or any(enemy.x == s.x and enemy.y == s.y for enemy in enemies) or b.x == player.x+move[0] and b.y == player.y+move[1]:
                b.state=True
                for door in b.doors:
                    map[door.y][door.x]="o"
                for w in b.wires:
                    if any(enemy.x == w[0] and enemy.y == w[1] for enemy in enemies):
                        for enemy in enemies:
                            enemy.here="o"
                    else:
                        map[w[1]][w[0]]="o"
            else:
                b.state=False
                for door in b.doors:
                    map[door.y][door.x]="D"
                for w in b.wires:
                    if any(enemy.x == w[0] and enemy.y == w[1] for enemy in enemies):
                        for enemy in enemies:
                            enemy.here="b"
                    else:
                        map[w[1]][w[0]]="b"

        #loop through switches and check
        for s in switches:
            if any(box.x == s.x and box.y == s.y for box in boxes) or any(enemy.x == s.x and enemy.y == s.y for enemy in enemies) or s.x == player.x+move[0] and s.y == player.y+move[1]:
                if s.state==False:
                    s.state=True
                    for door in s.doors:
                        map[door.y][door.x]="o"
                    if any(enemy.x == s.x and enemy.y == s.y for enemy in enemies):
                        for enemy in enemies:
                            enemy.here="s"
                    else:
                        map[s.y][s.x]="s"
                    for w in s.wires:
                        if any(enemy.x == w[0] and enemy.y == w[1] for enemy in enemies):
                            for enemy in enemies:
                                enemy.here="o"
                        else:
                            map[w[1]][w[0]]="o"
                else:
                    s.state=False
                    for door in s.doors:
                        map[door.y][door.x]="D"
                    if any(enemy.x == s.x and enemy.y == s.y for enemy in enemies):
                        for enemy in enemies:
                            enemy.here="s"
                    else:
                        map[s.y][s.x]="S"
                    for w in s.wires:
                        map[w[1]][w[0]]="b"

        #reset player pos
        if map[player.y][player.x] == '@':
            if map[player.y+1][player.x] == "#":
                map[player.y][player.x] = "_"
            else:
                map[player.y][player.x] = "."

        #move player and camera
        tileH = map[player.y][player.x+move[0]]
        if not tileH == "#" and not tileH == "=" and not tileH == "T" and not tileH == "/" and not tileH == "&":
            player.x += move[0]
        tileV = map[player.y+move[1]][player.x]
        if not tileV == "#" and not tileV == "=" and not tileV == "T" and not tileV == "/" and not tileV == "&":
            player.y += move[1]
        cam[0]=player.x-int(cam[2]/2)
        cam[1]=player.y-int(cam[3]/2)
        tile = map[player.y][player.x]

        #kill player
        if tile == "^" or tile == "~" or tile == "-" or tile == "$" or tile == "%" or tile == "E":
            os.system("cls")
            title=getTitle("gameOver")
            print(title)
            input("")
            os.system("cls")
            getLevel(level)

        #next level
        elif tile == "*":
            os.system("cls")
            title=getTitle("nextLevel")
            print(title)
            input("")    
            os.system("cls")
            level=int(level)
            level+=1
            getLevel(level)

        #find signs
        signPos=[0,0]
        for neighbor in neighbors:
            target=[player.x+neighbor[0],player.y+neighbor[1]]
            if map[target[1]][target[0]] == "T":
                signPos=[target[1],target[0]]

        #read sign
        if signPos!=[0,0]:
            textFile="levels\\text\\level"+str(level)+"-text-"+str(signPos[1])+"-"+str(signPos[0])+".txt"
            sign = open(textFile, "r")
            signText = sign.read()
        else:
            signText=""

        #move and reset player sprite
        move=[0,0]
        reset=map[player.y][player.x]
        map[player.y][player.x]="@"

        #loop through camera and draw map to display buffer
        pm=[]
        if len(map)-cam[1]-1 < cam[3]:
            height=len(map)
        else:
            height=cam[3]
        for iy in range(height):
            y=map[iy+cam[1]]
            py=""
            if len(y)-cam[0]-1 < cam[2]:
                width=len(y)-cam[0]-1
            else:
                width=cam[2]
            for ix in range(width):
                x=y[ix+cam[0]]
                #swap and colorise tiles
                if x=="/":
                    py+="  "
                elif x==":" or x=="R" or x=="." or x==">":
                    py+=colors.gray+". "
                elif x=="$":
                    py+=colors.green+"S "
                elif x=="%":
                    py+=colors.green+"s "
                elif x=="#":
                    py+=colors.yellow+"# "
                elif x==",":
                    py+=colors.gray+", "
                elif x=="^":
                    py+=colors.red+"^ "
                elif x=="\"":
                    py+=colors.red+"^ "
                elif x=="*":
                    py+=colors.purple+"* "
                elif x=="-":
                    py+=colors.yellow+"- "
                elif x=="~":
                    py+=colors.red+"~ "
                elif x=="E":
                    py+=colors.red+"E "
                elif x=="=":
                    py+=colors.gray+"= "
                elif x==";":
                    py+=colors.yellow+"; "
                elif x=="b":
                    py+=colors.blue+". "
                elif x=="o":
                    py+=colors.yellow+". "
                elif x=="s":
                    py+=colors.yellow+"s "
                else:
                    py+=colors.white+x+" "
                
            pm.append(py)

        #display camera, borders and signs
        screen=""
        screen+=colors.white+"  "+("_"*(cam[2]*2+1))+"\n"
        for p in pm:
            screen+=f'{colors.white+" | "+p: <{cam[2]*2+13}}'+colors.white+"| \n"
        screen+=" |"+("_"*(cam[2]*2+1))+"|" 
        for x in out:
            print(x)
        print(screen)
        for x in signText.split("\n"):
            width=(cam[2]*2+5)
            print(f'{x: ^{width}}')
        if saved==True:
            print("Game Saved")
        map[player.y][player.x]=reset

    #read player inputs
    if delay>= 10 and keyboard.is_pressed("space"):
        player.attacking=True
    if player.attacking==False:    
        if delay>= 10 and keyboard.is_pressed("w"):
            move[1]=-1
        if delay>= 10 and keyboard.is_pressed("s"):
            move[1]=1
        if delay>= 10 and keyboard.is_pressed("a"):
            move[0]=-1
        if delay>= 10 and keyboard.is_pressed("d"):
            move[0]=1
    if delay>= 10 and keyboard.is_pressed("esc"):
        exit()
        
    time.sleep(0.01)
    loops+=1
            

