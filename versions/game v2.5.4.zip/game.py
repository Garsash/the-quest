from levelHandler import Level
from camera import Camera
from objects.player import Player
from objects.sign import SignText
import time
import os

cheat=input("")
numbers=["0","1","2","3","4","5","6","7","8","9"]
for pos in range(len(cheat)):
    if not cheat[pos] in numbers:
        cheat=cheat.replace(cheat[pos]," ")
cheat=cheat.replace(" ","")

try:
    int(cheat)
except:
    cheat=1
level=cheat

level=Level(level)
camera=Camera(0,0)

firstTick=True
frame=0

while True:
    #keyboard yes?
    recievedInput=False
    inputs=Player.getInputs()
    for x in inputs:
        if inputs[x]==True:
            recievedInput=True
            break

    #if yes then do
    if recievedInput==True or firstTick==True:
        time.sleep(0.05)
        #get new possible inputs
        allInputs=Player.getInputs()
        for x in inputs:
            if allInputs[x]==True and inputs[x]==False:
                inputs[x]=True
        firstTick=False
        frame+=1

        #sort objects by update order
        update={}
        for obj in level.objects:
            if not obj.layer in update.keys():
                update[obj.layer]=[]
            update[obj.layer].append(obj)
        
        signText=SignText("")
        #update objects
        updates = dict(sorted(update.items()))
        index=0
        for x in updates:
            for obj in updates[x]:
                index+=1
                obj.tick(level,inputs=inputs,camera=camera,player=level.player,frame=frame,index=index,signText=signText)

        ###loop through all objects
        ##for obj in level.objects:
        ##    #tick each object
        ##    obj.tick(level,inputs=inputs,camera=camera)

        camera.draw(level,frame,signText)
        time.sleep(0.2)

input()
