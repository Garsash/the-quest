from textwrap import wrap
import os
import time
#import click
import keyboard
from rcolors import colors
import random

out=[]

#start_time = time.time()

#camera set up
cam=[0,0,15,15]
os.system("mode "+ str(cam[2]*2+5)+", "+str(cam[3]+9))

#tile groups
wallTiles = ["#","=","T","/","&","D", "w","H","h","|","?","r","k","Y"]
deathTiles = ["^","~","-","$","%","E","("]

#rnadom number generation
rndTable=[44, 195, 53, 132, 104, 57, 228, 119, 248, 34, 158, 68, 0, 246, 248, 213, 181, 225, 227, 13, 62, 133, 251, 103, 236, 72, 24, 250, 102, 90, 189, 73, 113, 203, 156, 210, 202, 180, 4, 27, 38, 57, 183, 8, 180, 123, 140, 19, 79, 42, 187, 105, 91, 175, 130, 108, 27, 11, 32, 158, 125, 108, 68, 94, 187, 222, 78, 12, 229, 6, 9, 141, 20, 1, 29, 110, 11, 199, 165, 113, 230, 171, 77, 12, 5, 46, 224, 239, 94, 205, 244, 53, 234, 35, 247, 38, 154, 13, 82, 38, 225, 95, 64, 91, 251, 33, 146, 48, 210, 2, 191, 7, 186, 199, 247, 183, 4, 213, 250, 93, 158, 146, 13, 111, 7, 118, 160, 25, 175, 78, 234, 94, 80, 72, 126, 93, 241, 162, 81, 147, 71, 7, 4, 100, 19, 66, 7, 157, 147, 195, 118, 184, 190, 41, 245, 253, 242, 50, 28, 245, 137, 136, 226, 18, 210, 251, 34, 59, 186, 199, 241, 0, 83, 150, 210, 220, 83, 88, 13, 49, 209, 146, 109, 38, 25, 133, 254, 216, 219, 205, 133, 241, 196, 146, 49, 76, 228, 101, 95, 5, 59, 141, 107, 49, 162, 92, 206, 1, 238, 77, 164, 171, 28, 50, 117, 106, 40, 107, 171, 31, 250, 156, 84, 52, 246, 236, 8, 11, 76, 197, 25, 230, 59, 19, 90, 49, 5, 158, 223, 109, 160, 14, 223, 97, 121, 235, 187, 39, 115, 50, 84, 203, 151, 185, 223, 248]

#get title card from files
def getTitle(name):
    #open and read
    title="titles\\"+name+".txt"
    titleFile = open(title, "r")
    titleLines = titleFile.readlines()
    title=""
    #loop and assign colours
    for lines in titleLines:
        line=""
        for character in lines:
            if character == "y":
                line+="\033[1;33;40m"
            elif character == "w":
                line+="\033[1;37;40m"
            elif character == "%":
                line+="\033[1;31;40m"
            elif character == "p":
                line+="\033[1;35;40m"
            else:
                line+=character
        title+=line
    return title

#define player object
class Player():
    def __init__(self,xPos,yPos):
        self.x = xPos
        self.y = yPos
        self.attacking=False

#define spike object
class Spike():
    def __init__(self,xPos,yPos,State,Timer):
        self.x = xPos
        self.y = yPos
        self.state = State
        self.maxTime = Timer
        self.time = 0

#define flamethrower object
class Flamethrower():
    def __init__(self,xPos,yPos,Stage,Facing,Range,Timer):
        self.x = xPos
        self.y = yPos
        self.stage = Stage
        self.facing = Facing
        self.range= Range
        self.maxTime = Timer
        self.time = 0

#define snake object
class Snake():
    def __init__(self,xPos,yPos,Segments):
        self.x = xPos
        self.y = yPos
        self.segments = Segments

#define snake segment object
class Segment():
    def __init__(self,xPos,yPos):
        self.x = xPos
        self.y = yPos

#define enemy object
class Enemy():
    def __init__(self,xPos,yPos):
        self.x = xPos
        self.y = yPos
        self.here = "."

#define box object
class Box():
    def __init__(self,xPos,yPos):
        self.x = xPos
        self.y = yPos
        self.here = "."

#define button object
class Button():
    def __init__(self,xPos,yPos,Doors,Wires):
        self.x = xPos
        self.y = yPos
        self.state = False
        self.doors = Doors
        self.wires=Wires

#define switch object
class Switch():
    def __init__(self,xPos,yPos,Doors,Wires):
        self.x = xPos
        self.y = yPos
        self.state = False
        self.doors = Doors
        self.wires=Wires

#define door object
class Door():
    def __init__(self,xPos,yPos):
        self.x = xPos
        self.y = yPos

#display opening title card
print(getTitle("title"))

#get level skip input
cheat=input("")
os.system("cls")

#try to skip levels

debug=False
if "d" in cheat:
    debug=True

times=True
if "t" in cheat:
    times=True

numbers=["0","1","2","3","4","5","6","7","8","9"]
for pos in range(len(cheat)):
    if not cheat[pos] in numbers:
        cheat=cheat.replace(cheat[pos]," ")
cheat=cheat.replace(" ","")

try:
    int(cheat)
except:
    cheat=1

level=cheat

first=True

#create global object arrays
spikes=[]
flames=[]
snakes=[]
enemies=[]
boxes=[]
buttons=[]
switches=[]
neighbors=[[-1,0],[0,-1],[1,0],[0,1]]

#create player
player=Player(0,0)

map=[]

#define get level function
def getLevel(Level):
        if times==True:
            start_time=time.time()
        #get and reset global variables
        global first, spikes, flames, snakes, enemies, cam, map, player, boxes, buttons, switches
        spikes=[]
        flames=[]
        snakes=[]
        enemies=[]
        boxes=[]
        buttons=[]
        switches=[]
        cam=[0,0,15,15]
        player=Player(0,0)
        map=[]
        
        fill=""
        for x in range(cam[2]):
            fill+="/"
		
        #open level file
        file="levels\level"+str(Level)+".txt"
        file = open(file, "r")
        lines = file.readlines()

        i=0
        #reset map
        map=[]

        #set up file format
        maxmap=0
        for line in lines:
            i+=1
            if i!=len(lines):
                line=line[:-1]
            #print(x)
            line=wrap(line+fill,1)
            map.append(line)
            if maxmap <= len(line):
                maxmap=len(line)

        fill2=[]
        for x in range(maxmap):
            fill2.append("/")
        for x in range(cam[3]):
            map.append(fill2)

        #loop through map
        for y in range(len(map)):
            for x in range(len(map[y])):
                #find and create spikes
                if map[y][x] == '^' or map[y][x] == ',':
                    spikes.append(Spike(x,y,0,3))
                if map[y][x] == '^' or map[y][x] == '"':
                    spikes.append(Spike(x,y,0,7))

                #find and create flamethrowers
                elif map[y][x] == '=':
                    flameDir=0
                    if map[y][x-1] in wallTiles:
                        flameDir=1
                    elif map[y][x+1] in wallTiles:
                        flameDir=-1
                    else:
                        continue
                    flames.append(Flamethrower(x,y,0,flameDir,3,7))

                #find and create snakes
                elif map[y][x] == '$':
                    #find body parts
                    body=[Segment(x,y)]
                    for bit in body:
                        for neighbor in neighbors:
                            target=[neighbor[0]+bit.x,neighbor[1]+bit.y]
                            if any(part.x==target[0] and part.y==target[1] for part in body):
                                continue
                            if map[target[1]][target[0]] == "%":
                                body.append(Segment(target[0],target[1]))
                    body.pop(0)
                    snakes.append(Snake(x,y,body))

                #find and create enemies
                elif map[y][x] == 'E':
                    enemies.append(Enemy(x,y))

                #find and create boxes
                elif map[y][x] == '&':
                    boxes.append(Box(x,y))

                #find and create buttons
                elif map[y][x] == 'p':
                    wires=[[x,y]]
                    doors=[]
                    #find wires
                    for wire in wires:
                        for neighbor in neighbors:
                            target=[neighbor[0]+wire[0],neighbor[1]+wire[1]]
                            if any(Wire[0]==target[0] and Wire[1]==target[1] for Wire in wires):
                                continue
                            if map[target[1]][target[0]] == "b":
                                wires.append([target[0],target[1]])
                            if map[target[1]][target[0]] == "D":
                                doors=[Door(target[0],target[1])]
                                #find doors
                                for door in doors:
                                    for meighbor in neighbors:
                                        Target=[meighbor[0]+door.x,meighbor[1]+door.y]
                                        if any(Door.x==Target[0] and Door.y==Target[1] for Door in doors):
                                            continue
                                        if map[Target[1]][Target[0]] == "D":
                                            doors.append(Door(Target[0],Target[1]))
                    wires.pop(0)
                    buttons.append(Button(x,y,doors,wires))

                #find and create switches
                elif map[y][x] == 'S':
                    wires=[[x,y]]
                    doors=[]
                    #find wires
                    for wire in wires:
                        for neighbor in neighbors:
                            target=[neighbor[0]+wire[0],neighbor[1]+wire[1]]
                            if any(Wire[0]==target[0] and Wire[1]==target[1] for Wire in wires):
                                continue
                            if map[target[1]][target[0]] == "b":
                                wires.append([target[0],target[1]])
                            if map[target[1]][target[0]] == "D":
                                doors=[Door(target[0],target[1])]
                                #find doors
                                for door in doors:
                                    for meighbor in neighbors:
                                        Target=[meighbor[0]+door.x,meighbor[1]+door.y]
                                        if any(Door.x==Target[0] and Door.y==Target[1] for Door in doors):
                                            continue
                                        if map[Target[1]][Target[0]] == "D":
                                            doors.append(Door(Target[0],Target[1]))
                    wires.pop(0)
                    switches.append(Switch(x,y,doors,wires))

                #find and move player
                elif map[y][x] == '@':
                    if map[y+1][x] == "#":
                        map[y][x]="_"
                    else:
                        map[y][x]="."
                    player.x=x
                    player.y=y

                #switch out animation shapes
                elif map[y][x] == '-' or map[y][x] == '~' or map[y][x] == ';':
                    if map[y+1][x] == "#":
                        map[y][x]="_"
                    else:
                        map[y][x]="."

                #random tile generation
                if map[y][x] == ".":
                    loc=(x*y)
                    while loc>255:
                        loc-=255
                    if rndTable[loc]>200:
                        map[y][x]="'"
                elif map[y][x] == "g":
                    loc=(x*y)
                    while loc>255:
                        loc-=255
                    if rndTable[loc]>200:
                        map[y][x]="G"
                elif map[y][x] == "#":
                    loc=(x*y)
                    while loc>255:
                        loc-=255
                    if rndTable[loc]>235:
                        map[y][x]="Y"
                        
        #set camera position
        cam[0]=player.x-int(cam[2]/2)
        cam[1]=player.y-int(cam[3]/2) 
        save=[]

        #put player on map
        map[player.y][player.x]="@"
        if times==True:
            end_time=time.time()
            out.append("level load: "+str(end_time-start_time))

#get initial level
getLevel(level)

#set up variables
loops=0
dir=1
      
move=[0,0]
delay=0
looped=0
savePoint=[0,0]

#-t out.append(end_time-start_time)

#gamer loop
while True:
    delay+=1
    #step frame if button press
    if delay>= 10 and move[0]!=0 or delay>= 10 and move[1]!=0 or first==True:
        if times==True:
            start_time=time.time()
        delay=0
        saved=False
        first=False
        looped+=1
        
        #clear screen
        os.system("cls")

        #loop through spikes and change state
        for spike in spikes:
            #up
            if spike.time == 0:
                map[spike.y][spike.x]="^"
                spike.state = 1
            #down
            elif spike.time == 2:
                map[spike.y][spike.x]=","
                spike.state = 0
            spike.time+=1
            #reset
            if spike.time > spike.maxTime:
                spike.time = 0

        #loop through flamethrowers and change state
        for flame in flames:
            #loop range
            for dist in range(flame.range):
                #flames
                if flame.time >= 0 and flame.time <= 3:
                    if (dist+(flame.time%2))%2==0:
                        map[flame.y][flame.x+((dist+1)*flame.facing)]="~"
                    else:
                        map[flame.y][flame.x+((dist+1)*flame.facing)]="-"
                #reset
                elif flame.time==4:
                    map[flame.y][flame.x+((dist+1)*flame.facing)]="."
                #warning
                elif flame.time==7:
                    map[flame.y][flame.x+(1*flame.facing)]=";"
            flame.time+=1
            #reset
            if flame.time > flame.maxTime:
                flame.time = 0

        #loop through snakes and move forward
        for snake in snakes:
            #direction vecors
            forward=[snake.x-snake.segments[0].x,snake.y-snake.segments[0].y]
            left=[forward[1]*-1,forward[0]]
            right=[forward[1],forward[0]*-1]

            #find next space
            if map[snake.y+forward[1]][snake.x+forward[0]] == ":" or map[snake.y+forward[1]][snake.x+forward[0]] == "(":
                nextPos=[snake.x+forward[0],snake.y+forward[1]]
            elif map[snake.y+left[1]][snake.x+left[0]]:
                nextPos=[snake.x+left[0],snake.y+left[1]]
            elif map[snake.y+right[1]][snake.x+right[0]]:
                nextPos=[snake.x+right[0],snake.y+right[1]]

            #delete end segment
            map[snake.segments[-1].y][snake.segments[-1].x]=":"
                
            for neighbor in neighbors:
                if map[snake.segments[-1].y+neighbor[1]][snake.segments[-1].x+neighbor[0]] == "#":
                    map[snake.segments[-1].y][snake.segments[-1].x]="("

            snake.segments.pop(-1)

            #add new segment
            map[snake.y][snake.x]="%"
            snake.segments.insert(0,Segment(snake.x,snake.y))

            #move forward
            snake.x=nextPos[0]
            snake.y=nextPos[1]
            map[snake.y][snake.x]="$"

        #loop through enemies and move
        for enemy in enemies:
            #find distance from player
            distx=player.x-enemy.x
            disty=player.y-enemy.y
            target=[0,0]
            
            if abs(distx) <= 6 and abs(disty) <= 6:
                #create scent map
                scentMap=[]
                for y in range(13):
                    row=[]
                    for x in range(13):
                        row.append(26)
                    scentMap.append(row)

                #create searching map
                searching=[]
                for y in range(13):
                    row=[]
                    for x in range(13):
                        row.append(False)
                    searching.append(row)

                #set player location
                searching[6][6]=True
                scentMap[6][6]=0
                nodes=[[6,6]]

                #loop through nodes
                for node in nodes:
                    #look at neighbors
                    for neighbor in neighbors:
                        #variable set up
                        neighborx=node[0]+neighbor[0] #nx
                        neighbory=node[1]+neighbor[1] #ny
                        nodex=node[0] #hx
                        nodey=node[1] #hy
                        worldy=player.y+neighbory-6
                        worldx=player.x+neighborx-6
                        
                        #if inside map
                        if neighbory < 0 or neighbory >= 13:
                            continue
                        if neighborx < 0 or neighborx >= 13:
                            continue

                        here=scentMap[nodey][nodex]
                        #if not searched already
                        if searching[neighbory][neighborx] == False:
                            #is there a wall
                            state=map[worldy][worldx]
                            if state in wallTiles or state in deathTiles and state != "E":
                                continue

                            #get smallest scent
                            if scentMap[neighbory][neighborx] >= here:
                                scentMap[neighbory][neighborx]=here+1
                                nodes.append([neighborx,neighbory])
                            searching[neighbory][neighborx]=True

                            #found enemy
                            if state=="E" and worldx==enemy.x and worldy==enemy.y:
                                #out.append([worldx,worldy])
#                                Loc=[worldx,worldy]
#                                out.append("enemy pos "+str(Loc))
#                                if Loc in foundEnemies:
#                                    continue
                                nodes=[]
                                lowest=26
                                target=[0,0]
                                values=[]
                                
                                #look at neighbors
                                for Neighbor in neighbors:   
                                    enemyx=neighborx+Neighbor[0]
                                    enemyy=neighbory+Neighbor[1]
                                    if enemyy < 0 or enemyy >= 13:
                                        continue
                                    if enemyx < 0 or enemyx >= 13:
                                        continue
                                    #find values
                                    if map[player.y+enemyy-6][player.x+enemyx-6] == "E":
                                        continue
                                    values.append([Neighbor[0],Neighbor[1],scentMap[enemyy][enemyx]])

                                #get smallest values
                                minV=24
                                for min in values:
                                    if min[2] < minV:
                                        minV=min[2]

                                #pick random closest direction
                                closest=[value for value in values if value[2]==minV]
                                if len(closest)>=1:
                                    choice=random.choice(closest)
                                    target=[choice[0],choice[1]]
                                break
            #move enemy
            map[enemy.y][enemy.x]=enemy.here
            enemy.x+=target[0]
            enemy.y+=target[1]
            enemy.here=map[enemy.y][enemy.x]
            map[enemy.y][enemy.x]="E"
            
        #if player moving box
        if map[player.y+move[1]][player.x+move[0]] == "&":
            #loop through boxes
            for box in boxes:
                #find correct box
                if box.x == player.x+move[0] and box.y == player.y+move[1]:
                    #move box
                    tileTest=map[box.y+move[1]][box.x+move[0]]
                    if not tileTest in wallTiles and not tileTest in deathTiles:
                        map[box.y][box.x] = box.here
                        box.x+=move[0]
                        box.y+=move[1]
                        box.here=map[box.y][box.x]
                        map[box.y][box.x]="&"
                    else:
                        move=[0,0]
                        
        #loop through buttons and check          
        for button in buttons:
            #if pressed
            if any(box.x == button.x and box.y == button.y for box in boxes) or any(enemy.x == s.x and enemy.y == s.y for enemy in enemies) or button.x == player.x+move[0] and button.y == player.y+move[1]:
                button.state=True
                for door in button.doors:
                    map[door.y][door.x]="o"
                for wire in button.wires:
                    if any(enemy.x == wire[0] and enemy.y == wire[1] for enemy in enemies):
                        for enemy in enemies:
                            enemy.here="o"
                    else:
                        map[wire[1]][wire[0]]="o"
            else:
                button.state=False
                for door in button.doors:
                    map[door.y][door.x]="D"
                for wire in button.wires:
                    if any(enemy.x == wire[0] and enemy.y == wire[1] for enemy in enemies):
                        for enemy in enemies:
                            enemy.here="b"
                    else:
                        map[wire[1]][wire[0]]="b"

        #loop through switches and check
        for switch in switches:
            if any(box.x == switch.x and box.y == switch.y for box in boxes) or any(enemy.x == switch.x and enemy.y == switch.y for enemy in enemies) or switch.x == player.x+move[0] and switch.y == player.y+move[1]:
                if switch.state==False:
                    switch.state=True
                    for door in switch.doors:
                        map[door.y][door.x]="o"
                    if any(enemy.x == switch.x and enemy.y == switch.y for enemy in enemies):
                        for enemy in enemies:
                            enemy.here="s"
                    else:
                        map[switch.y][switch.x]="s"
                    for wire in switch.wires:
                        if any(enemy.x == wire[0] and enemy.y == wire[1] for enemy in enemies):
                            for enemy in enemies:
                                enemy.here="o"
                        else:
                            map[wire[1]][wire[0]]="o"
                else:
                    switch.state=False
                    for door in switch.doors:
                        map[door.y][door.x]="D"
                    if any(enemy.x == switch.x and enemy.y == switch.y for enemy in enemies):
                        for enemy in enemies:
                            enemy.here="S"
                    else:
                        map[switch.y][switch.x]="S"
                    for wire in switch.wires:
                        map[wire[1]][wire[0]]="b"

        #reset player pos
        if map[player.y][player.x] == '@':
            if map[player.y+1][player.x] == "#":
                map[player.y][player.x] = "_"
            else:
                map[player.y][player.x] = "."

        #move player and camera
        tileH = map[player.y][player.x+move[0]]
        if not tileH in wallTiles:
            player.x += move[0]
        tileV = map[player.y+move[1]][player.x]
        if not tileV in wallTiles:
            player.y += move[1]
        cam[0]=player.x-int(cam[2]/2)
        cam[1]=player.y-int(cam[3]/2)
        tile = map[player.y][player.x]

        #kill player
        if tile in deathTiles:
            os.system("cls")
            title=getTitle("gameOver")
            print(title)
            input("")
            os.system("cls")
            getLevel(level)

        #next level
        elif tile == "*":
            os.system("cls")
            title=getTitle("nextLevel")
            print(title)
            input("")    
            os.system("cls")
            level=int(level)
            level+=1
            getLevel(level)

        #find signs
        signPos=[0,0]
        for neighbor in neighbors:
            target=[player.x+neighbor[0],player.y+neighbor[1]]
            if map[target[1]][target[0]] == "T":
                signPos=[target[1],target[0]]

        #read sign
        if signPos!=[0,0]:
            textFile="levels\\text\\level"+str(level)+"-text-"+str(signPos[1])+"-"+str(signPos[0])+".txt"
            sign = open(textFile, "r")
            signText = sign.read()
        else:
            signText=""

        #move and reset player sprite
        move=[0,0]
        reset=map[player.y][player.x]
        map[player.y][player.x]="@"

        
        if times==True:
            start_draw_time=time.time()
        #loop through camera and draw map to display buffer
        cameraBuffer=[] #pm
        if len(map)-cam[1]-1 < cam[3]:
            height=len(map)
        else:
            height=cam[3]
        for iy in range(height):
            line=map[iy+cam[1]]
            lineBuffer=""
            if len(line)-cam[0]-1 < cam[2]:
                width=len(line)-cam[0]-1
            else:
                width=cam[2]
            for ix in range(width):
                tile=line[ix+cam[0]]
                #swap and colorise tiles
                if tile=="/":
                    lineBuffer+="  "
                elif tile==":" or tile=="R" or tile=="." or tile==">":
                        lineBuffer+=colors.gray+". "
                elif tile=="'":
                        lineBuffer+=colors.gray+", "
                elif tile=="#":
                    lineBuffer+=colors.yellow+"# "
                elif tile=="Y":
                        lineBuffer+=colors.yellow+"% "
                elif tile=="$":
                    lineBuffer+=colors.green+"S "
                elif tile=="%":
                    lineBuffer+=colors.green+"s "
                elif tile=="r":
                    lineBuffer+=colors.yellow+"R "
                elif tile=="g":
                    lineBuffer+=colors.green+". "
                elif tile=="G":
                    lineBuffer+=colors.green+", "
                elif tile=="t":
                    lineBuffer+=colors.white+"- "
                elif tile=="?":
                    lineBuffer+=colors.green+"? "
                elif tile=="W":
                    lineBuffer+=colors.yellow+". "
                elif tile=="H":
                    lineBuffer+=colors.yellow+"\ "
                elif tile=="h":
                    lineBuffer+=colors.yellow+"/ "
                elif tile=="k":
                    lineBuffer+=colors.yellow+"[]"
                elif tile=="l":
                    lineBuffer+=colors.yellow+"{}"
                elif tile=="|":
                     lineBuffer+=colors.yellow+"| "
                elif tile=="w":
                    if (looped+ix+player.x+iy+player.y)%3==0:
                        lineBuffer+=colors.blue+"~ "
                    elif (looped+ix+player.x+iy+player.y)%3==1:
                        lineBuffer+=colors.blue+"~~"
                    elif (looped+ix+player.x+iy+player.y)%3==2:
                        lineBuffer+=colors.blue+" ~"
                elif tile=="f":
                    if (looped+ix+player.x+iy+player.y)%2==0:
                        lineBuffer+=colors.yellow+"t "
                    elif (looped+ix+player.x+iy+player.y)%2==1:
                        lineBuffer+=colors.yellow+"f "
                elif tile==",":
                    lineBuffer+=colors.red+", "
                elif tile=="^":
                    lineBuffer+=colors.red+"^ "
                elif tile=="\"":
                    lineBuffer+=colors.red+"^ "
                elif tile=="*":
                    lineBuffer+=colors.purple+"* "
                elif tile=="-":
                    lineBuffer+=colors.yellow+"- "
                elif tile=="~":
                    lineBuffer+=colors.red+"~ "
                elif tile=="E":
                    lineBuffer+=colors.red+"E "
                elif tile=="=":
                    lineBuffer+=colors.gray+"= "
                elif tile==";":
                    lineBuffer+=colors.yellow+"; "
                elif tile=="b":
                    lineBuffer+=colors.blue+". "
                elif tile=="o":
                    lineBuffer+=colors.yellow+". "
                elif tile=="s":
                    lineBuffer+=colors.yellow+"s "
                elif tile=="(":
                    lineBuffer+=colors.red+"~ "
                else:
                    lineBuffer+=colors.white+tile+" "
                
            cameraBuffer.append(lineBuffer)

        #display camera, borders and signs
        screen=""
        screen+=colors.white+"  "+("_"*(cam[2]*2+1))+"\n"
        for line in cameraBuffer:
            screen+=f'{colors.white+" | "+line: <{cam[2]*2+13}}'+colors.white+"| \n"
        screen+=" |"+("_"*(cam[2]*2+1))+"|" 
        for output in out:
            print(output)
        out=[]
        print(screen)
        for line in signText.split("\n"):
            width=(cam[2]*2+5)
            print(f'{line: ^{width}}')
        if saved==True:
            print("Game Saved")
        map[player.y][player.x]=reset
        
        if times==True:
            end_draw_time=time.time()
            print("draw: "+str(end_draw_time-start_draw_time))
        if times==True:
            end_time=time.time()
            print("tick: "+str(end_time-start_time))
        #-t print(end_time - start_time)

    #read player inputs
    if delay>= 10 and keyboard.is_pressed("space"):
        player.attacking=True
    if player.attacking==False:    
        if delay>= 10 and keyboard.is_pressed("w"):
            move[1]=-1
        if delay>= 10 and keyboard.is_pressed("s"):
            move[1]=1
        if delay>= 10 and keyboard.is_pressed("a"):
            move[0]=-1
        if delay>= 10 and keyboard.is_pressed("d"):
            move[0]=1
    if delay>= 10 and keyboard.is_pressed("esc"):
        exit()
        
    time.sleep(0.01)
    loops+=1
            

