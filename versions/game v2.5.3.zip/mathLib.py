class Vector():
    def __init__(self,x:int=0, y:int=0):
        self.x=x
        self.y=y
    
    def transformLeft(self):
        x,y=self.y*-1,self.x
        return Vector(x,y)

    def transformRight(self):
        x,y=self.y,self.x*-1
        return Vector(x,y)

    def neighbors():
        return [Vector(0,-1),Vector(1,0),Vector(0,1),Vector(-1,0)]

    def __add__(self, other):
        return Vector(self.x+other.x,self.y+other.y)

    def __subtract__(self, other):
        return Vector(self.x-other.x,self.y-other.y)

rndTable=open("rnd.txt").read().strip().split(",")
for x in range(len(rndTable)):
    rndTable[x]=int(rndTable[x])

class Random():
    global rndTable
    
    def setRandom(x):
        return rndTable[x]