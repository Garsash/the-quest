from levelHandler import Level

level=Level(r"levels/level1.txt")

for y in level.tiles:
    line=""
    for x in y:
        line+=x
    print(line)
for x in level.objects:
    print(x)
input()