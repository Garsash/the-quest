#define player object
class Player():
    def __init__(self,xPos,yPos):
        self.x = xPos
        self.y = yPos
        self.attacking=False

    def moveBox(self):
        #loop through boxes
        for box in boxes:
            #find correct box
            if box.x == player.x+move[0] and box.y == player.y+move[1]:
                box.move(move[0],move[1])