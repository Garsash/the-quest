from objects.spike import *

wallTiles = ["#","=","T","/","&","D", "w","H","h","|","?","r","k","Y"]
deathTiles = ["^","~","-","$","%","E","("]

def fill2DArray(array,char):
    maxLen=0
    for row in array:
        if len(row)>maxLen:
            maxLen=len(row)
    for row in range(len(array)):
        while len(array[row])!=maxLen:
            array[row].append(char)
    return array

class Level():
    tiles=[[]]
    objects=[]

    def readFile(self,fileDirectory):
        file=open(fileDirectory,"r")
        lines=file.readlines()
        for line in range(len(lines)):
            lines[line]=lines[line].strip().split(" ")
        lines=fill2DArray(lines,"/")

        #print(lines)
        return lines

    def getTile(self,x,y):
        return self.tiles[y][x]

    def setTile(self,x,y,tile):
        self.tiles[y][x]=str(tile)

    def objectCheck(self,object,tile,x,y):
        if tile in object.instantiationTiles:
            object.create(x,y,self)

    def createObject(self,object):
        self.objects.append(object)

    def getObjects(self):
        for y in range(len(self.tiles)):
            for x in range(len(self.tiles[y])):
                tile=self.getTile(x,y)
                print(tile)
                self.objectCheck(Spike,tile,x,y)

    def __init__(self,fileDirectory=""):
        if fileDirectory!="":
            self.tiles=self.readFile(fileDirectory)
            self.getObjects()
