import random

out=[]

for x in range(256):
    number=random.randint(0,255)
    out.append(number)

print(out)

while True:
    a=0
