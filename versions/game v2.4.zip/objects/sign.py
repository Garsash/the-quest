from mathLib import Vector
from rcolors import colors
colorise=colors.colorise

#define end object
class Sign():
    instantiationTiles=["T"]
    directions=[Vector(0,-1),Vector(0,1),Vector(-1,0),Vector(1,0)]

    @classmethod
    def create(cls,x,y,level): 
        sign=Sign(x,y)
        level.createObject(sign)

    def __init__(self,x,y,tile="T",layer=11):
        self.x = x
        self.y = y
        self.tile=tile
        self.layer=layer

    def tick(self,level,player,signText, **kwargs):
        for x in self.directions:
            if player.x==self.x+x.x and player.y==self.y+x.y:
                fileDirectory="levels\\text\\level"+str(level.level)+"-text-"+str(self.x)+"-"+str(self.y)+".txt"
                file=open(fileDirectory,"r")
                signText.text=file.read().splitlines()

    def draw(self, **kwargs):
        return self.tile
    
class SignText():
    def __init__(self,text=""):
        self.text=text