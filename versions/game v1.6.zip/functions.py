def getMap(x,y):
    global map
    return map[y][x]

def setMap(x,y,tile):
    global map
    map[y][x]=str(tile)