from functions import *

#define player object
class Player():
    def __init__(self,xPos,yPos):
        self.x = xPos
        self.y = yPos
        self.attacking=False

    def moveBox(self):
        #loop through boxes
        for box in boxes:
            #find correct box
            if box.x == player.x+move[0] and box.y == player.y+move[1]:
                box.move(move[0],move[1])

#define spike object
class Spike():
    @classmethod
    def create(cls,x,y,map):
        tile=getMap(x,y)  
        global spikes    

        if tile == '^' or tile == ',':
            spikes.append(Spike(x,y,0,3))
        if tile == '^' or tile == '"':
            spikes.append(Spike(x,y,0,7))

    def __init__(self,xPos,yPos,State,Timer):
        self.x = xPos
        self.y = yPos
        self.state = State
        self.maxTime = Timer
        self.time = 0
    
    def tick(self):
        #up
        if self.time == 0:
            map[self.y][self.x]="^"
            self.state = 1
        #down
        elif self.time == 2:
            map[self.y][self.x]=","
            self.state = 0
        self.time+=1
        #reset
        if self.time > self.maxTime:
            self.time = 0

#define flamethrower object
class Flamethrower():
    @classmethod
    def create(cls,x,y,map):
        tile=getMap(x,y)  
        left=getMap(x-1,y)  
        right=getMap(x+1,y)  
        global flames   

        #find and create flamethrowers
        if tile == '=':
            flameDir=0
            if left in wallTiles:
                flameDir=1
            elif right in wallTiles:
                flameDir=-1
            else:
                return
            flames.append(Flamethrower(x,y,0,flameDir,3,7))

    def __init__(self,xPos,yPos,Stage,Facing,Range,Timer):
        self.x = xPos
        self.y = yPos
        self.stage = Stage
        self.facing = Facing
        self.range= Range
        self.maxTime = Timer
        self.time = 0
    
    def tick(self):
        #loop range
        for dist in range(self.range):
            #selfs
            if self.time >= 0 and self.time <= 3:
                if (dist+(self.time%2))%2==0:
                    map[self.y][self.x+((dist+1)*self.facing)]="~"
                else:
                    map[self.y][self.x+((dist+1)*self.facing)]="-"
            #reset
            elif self.time==4:
                map[self.y][self.x+((dist+1)*self.facing)]="."
            #warning
            elif self.time==7:
                map[self.y][self.x+(1*self.facing)]=";"
        self.time+=1
        #reset
        if self.time > self.maxTime:
            self.time = 0

#define snake object
class Snake():
    def __init__(self,xPos,yPos,Segments):
        self.x = xPos
        self.y = yPos
        self.segments = Segments
    
    def getDirections(self,previousSegment):
        #forward=[self.x-previousSegment.x,self.y-previousSegment.y]
        forward=Vector(self.x-previousSegment.x,self.y-previousSegment.y)
        #out.append(str(aforward.x)+str(aforward.y))
        #left=[forward[1]*-1,forward[0]]
        left=forward.transformLeft()
        #out.append(str(vleft.x)+str(vleft.y))
        #right=[forward[1],forward[0]*-1]
        right=forward.transformRight()
        #out.append(str(vright.x)+str(vright.y))
        #out.append("^ "+str(aforward.x)+", "+str(aforward.y)+" < "+str(vleft.x)+", "+str(vleft.y)+" > "+str(vright.x)+", "+str(vright.y))
        return forward,left,right

    def tick(self):
        #direction vecors
        forward,left,right=self.getDirections(self.segments[0])

        #find next space
        if getMap(self.x+forward.x,self.y+forward.y) == ":" or getMap(self.x+forward.x,self.y+forward.y) == "(":
            nextPos=Vector(self.x+forward.x,self.y+forward.y)
        elif getMap(self.x+left.x,self.y+left.y) == ":" or getMap(self.x+left.x,self.y+left.y) == "(":
            nextPos=Vector(self.x+left.x,self.y+left.y)
        elif getMap(self.x+right.x,self.y+right.y) == ":" or getMap(self.x+right.x,self.y+right.y) == "(":
            nextPos=Vector(self.x+right.x,self.y+right.y)

        #delete end segment
        setMap(self.segments[-1].x,self.segments[-1].y,":")
        for neighbor in neighborVectors:
            if getMap(self.segments[-1].x+neighbor.x,self.segments[-1].y+neighbor.y) == "#":
                setMap(self.segments[-1].x,self.segments[-1].y,"(")

        self.segments.pop(-1)

        #add new segment
        setMap(self.x,self.y,"%")
        self.segments.insert(0,Segment(self.x,self.y))

        #move forward
        self.x=nextPos.x
        self.y=nextPos.y
        setMap(self.x,self.y,"$")

#define snake segment object
class Segment():
    def __init__(self,xPos,yPos):
        self.x = xPos
        self.y = yPos

#define enemy object
class Enemy():
    def __init__(self,xPos,yPos):
        self.x = xPos
        self.y = yPos
        self.here = "."

    def tick(self):
        #find distance from player
        distx=player.x-enemy.x
        disty=player.y-enemy.y
        target=[0,0]

        if abs(distx) <= 6 and abs(disty) <= 6:
            #create scent map
            scentMap=[]
            for y in range(13):
                row=[]
                for x in range(13):
                    row.append(26)
                scentMap.append(row)

            #create searching map
            searching=[]
            for y in range(13):
                row=[]
                for x in range(13):
                    row.append(False)
                searching.append(row)

            #set player location
            searching[6][6]=True
            scentMap[6][6]=0
            nodes=[[6,6]]

            #loop through nodes
            for node in nodes:
                #look at neighbors
                for neighbor in neighbors:
                    #variable set up
                    neighborx=node[0]+neighbor[0] #nx
                    neighbory=node[1]+neighbor[1] #ny
                    nodex=node[0] #hx
                    nodey=node[1] #hy
                    worldy=player.y+neighbory-6
                    worldx=player.x+neighborx-6

                    #if inside map
                    if neighbory < 0 or neighbory >= 13:
                        continue
                    if neighborx < 0 or neighborx >= 13:
                        continue

                    here=scentMap[nodey][nodex]
                    #if not searched already
                    if searching[neighbory][neighborx] == False:
                        #is there a wall
                        state=map[worldy][worldx]
                        if state in wallTiles or state in deathTiles and state != "E":
                            continue

                        #get smallest scent
                        if scentMap[neighbory][neighborx] >= here:
                            scentMap[neighbory][neighborx]=here+1
                            nodes.append([neighborx,neighbory])
                        searching[neighbory][neighborx]=True

                        #found enemy
                        if state=="E" and worldx==enemy.x and worldy==enemy.y:
                            #out.append([worldx,worldy])
                            #Loc=[worldx,worldy]
                            #out.append("enemy pos "+str(Loc))
                            #if Loc in foundEnemies:
                            #    continue
                            nodes=[]
                            lowest=26
                            target=[0,0]
                            values=[]

                            #look at neighbors
                            for Neighbor in neighbors:   
                                enemyx=neighborx+Neighbor[0]
                                enemyy=neighbory+Neighbor[1]
                                if enemyy < 0 or enemyy >= 13:
                                    continue
                                if enemyx < 0 or enemyx >= 13:
                                    continue
                                #find values
                                if map[player.y+enemyy-6][player.x+enemyx-6] == "E":
                                    continue
                                values.append([Neighbor[0],Neighbor[1],scentMap[enemyy][enemyx]])

                            #get smallest values
                            minV=24
                            for min in values:
                                if min[2] < minV:
                                    minV=min[2]

                            #pick random closest direction
                            closest=[value for value in values if value[2]==minV]
                            if len(closest)>=1:
                                choice=random.choice(closest)
                                target=[choice[0],choice[1]]
                            break
        #move enemy
        map[enemy.y][enemy.x]=enemy.here
        enemy.x+=target[0]
        enemy.y+=target[1]
        enemy.here=map[enemy.y][enemy.x]
        map[enemy.y][enemy.x]="E"

#define box object
class Box():
    def __init__(self,xPos,yPos):
        self.x = xPos
        self.y = yPos
        self.here = "."
    
    def move(self,moveX,moveY):
        #move box
        tileTest=map[self.y+moveY][self.x+moveX]
        if not tileTest in wallTiles and not tileTest in deathTiles:
            map[self.y][self.x] = self.here
            self.x+=moveX
            self.y+=moveY
            self.here=map[self.y][self.x]
            map[self.y][self.x]="&"
        else:
            move=[0,0]

#define button object
class Button():
    def __init__(self,xPos,yPos,Doors,Wires):
        self.x = xPos
        self.y = yPos
        self.state = False
        self.doors = Doors
        self.wires=Wires
    
    def pressed(self):
        self.state=True
        for door in self.doors:
            map[door.y][door.x]="o"
        for wire in self.wires:
            if any(enemy.x == wire[0] and enemy.y == wire[1] for enemy in enemies):
                for enemy in enemies:
                    enemy.here="o"
            else:
                map[wire[1]][wire[0]]="o"

    def released(self):
        self.state=False
        for door in self.doors:
            map[door.y][door.x]="D"
        for wire in self.wires:
            if any(enemy.x == wire[0] and enemy.y == wire[1] for enemy in enemies):
                for enemy in enemies:
                    enemy.here="b"
            else:
                map[wire[1]][wire[0]]="b"

    def tick(self):
        #if pressed
        if any(box.x == self.x and box.y == self.y for box in boxes) or any(enemy.x == self.x and enemy.y == self.y for enemy in enemies) or self.x == player.x+move[0] and self.y == player.y+move[1]:
            self.pressed()
        else:
            self.released()

#define switch object
class Switch():
    def __init__(self,xPos,yPos,Doors,Wires):
        self.x = xPos
        self.y = yPos
        self.state = False
        self.doors = Doors
        self.wires=Wires

    def tick():
        if any(box.x == self.x and box.y == self.y for box in boxes) or any(enemy.x == self.x and enemy.y == self.y for enemy in enemies) or self.x == player.x+move[0] and self.y == player.y+move[1]:
                if self.state==False:
                    self.state=True
                    for door in self.doors:
                        map[door.y][door.x]="o"
                    if any(enemy.x == self.x and enemy.y == self.y for enemy in enemies):
                        for enemy in enemies:
                            enemy.here="s"
                    else:
                        map[self.y][self.x]="s"
                    for wire in self.wires:
                        if any(enemy.x == wire[0] and enemy.y == wire[1] for enemy in enemies):
                            for enemy in enemies:
                                enemy.here="o"
                        else:
                            map[wire[1]][wire[0]]="o"
                else:
                    self.state=False
                    for door in self.doors:
                        map[door.y][door.x]="D"
                    if any(enemy.x == self.x and enemy.y == self.y for enemy in enemies):
                        for enemy in enemies:
                            enemy.here="S"
                    else:
                        map[self.y][self.x]="S"
                    for wire in self.wires:
                        map[wire[1]][wire[0]]="b"

#define door object
class Door():
    def __init__(self,xPos,yPos):
        self.x = xPos
        self.y = yPos