import os
os.system("color")

colorValues={
        "red":"\033[1;31;40m",
        "yellow":"\033[1;33;40m",
        "green":"\033[1;32;40m",
        "cyan":"\033[1;36;40m",
        "blue":"\033[1;34;40m",
        "purple":"\033[1;35;40m",
        "white":"\033[1;37;40m",
        "gray":"\033[1;30;40m"
    }

red="\033[1;31;40m"
yellow="\033[1;33;40m"
green="\033[1;32;40m"
cyan="\033[1;36;40m"
blue="\033[1;34;40m"
purple="\033[1;35;40m"
white="\033[1;37;40m"
gray="\033[1;30;40m"

class colors:
    global colorValues,red,yellow,green,cyan,blue,purple,white,gray

    #def color(color):
    #    if isinstance(color, int)==False:
    #        raise Exeption("Not an integer")
    #    return "\033[9"+str(color)+"m"
    
    def colorise(string,color,reset=True):
        if reset==True:
            return colorValues[color]+string+white
        else:
            return colorValues[color]+string
    
    def color(color):
        return colorValues[color]
