from levelHandler import Level
from camera import Camera
from objects.player import Player
import time
import os

level=Level(1)
camera=Camera(0,0)

firstTick=True
frame=0
while True:
    #keyboard yes?
    recievedInput=False
    inputs=Player.getInputs()
    for x in inputs:
        if inputs[x]==True:
            recievedInput=True
            break

    #if yes then do
    if recievedInput==True or firstTick==True:
        time.sleep(0.05)
        #get new possible inputs
        allInputs=Player.getInputs()
        for x in inputs:
            if allInputs[x]==True and inputs[x]==False:
                inputs[x]=True
        firstTick=False
        frame+=1

        #sort objects by update order
        update={}
        for obj in level.objects:
            if not obj.layer in update.keys():
                update[obj.layer]=[]
            update[obj.layer].append(obj)
        
        #update objects
        updates = dict(sorted(update.items()))
        for x in updates:
            for obj in updates[x]:
                obj.tick(level,inputs=inputs,camera=camera,player=level.player)

        ###loop through all objects
        ##for obj in level.objects:
        ##    #tick each object
        ##    obj.tick(level,inputs=inputs,camera=camera)

        camera.draw(level,frame)
        time.sleep(0.2)

input()
