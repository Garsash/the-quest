from textwrap import wrap
import os
import time
#import click
import keyboard
from rcolors import colors
import random
#file=input("Enter Name of Map File: ")
#if file == "":
#	file = "map.txt"
#if file[4:] != ".txt":
#	file+=".txt"
#os.system("cls")

cam=[0,0,15,15]
os.system("mode "+ str(cam[2]*2+5)+", "+str(cam[3]+9))

def getTitle(name):
    title="titles\\"+name+".txt"
    t = open(title, "r")
    tl = t.readlines()
    title=""
    for l in tl:
        line=""
        for c in l:
            if c == "y":
                line+="\033[1;33;40m"
            elif c == "w":
                line+="\033[1;37;40m"
            elif c == "%":
                line+="\033[1;31;40m"
            elif c == "p":
                line+="\033[1;35;40m"
            else:
                line+=c
        title+=line
    return title

class Player():
    def __init__(self,xPos,yPos):
        self.x = xPos
        self.y = yPos

class Spike():
    def __init__(self,xPos,yPos,State,Timer):
        self.x = xPos
        self.y = yPos
        self.state = State
        self.maxTime = Timer
        self.time = 0

class Flamethrower():
    def __init__(self,xPos,yPos,Stage,Facing,Range,Timer):
        self.x = xPos
        self.y = yPos
        self.stage = Stage
        self.facing = Facing
        self.range= Range
        self.maxTime = Timer
        self.time = 0

class Snake():
    def __init__(self,xPos,yPos,Segments):
        self.x = xPos
        self.y = yPos
        self.segments = Segments

class Segment():
    def __init__(self,xPos,yPos):
        self.x = xPos
        self.y = yPos

class Enemy():
    def __init__(self,xPos,yPos):
        self.x = xPos
        self.y = yPos
        self.here = "."

class Box():
    def __init__(self,xPos,yPos):
        self.x = xPos
        self.y = yPos
        self.here = "."

class Button():
    def __init__(self,xPos,yPos,Doors,Wires):
        self.x = xPos
        self.y = yPos
        self.state = False
        self.doors = Doors
        self.wires=Wires
        
class Switch():
    def __init__(self,xPos,yPos,Doors,Wires):
        self.x = xPos
        self.y = yPos
        self.state = False
        self.doors = Doors
        self.wires=Wires

class Door():
    def __init__(self,xPos,yPos):
        self.x = xPos
        self.y = yPos

title="titles\\title.txt"
t = open(title, "r")
tl = t.readlines()
title=getTitle("title")
print(title)

cheat=input("")
os.system("cls")

try:
    int(cheat)
except:
    cheat=1

level=cheat

first=True

spikes=[]
flames=[]
snakes=[]
enemies=[]
boxes=[]
buttons=[]
switches=[]
neighbors=[[-1,0],[0,-1],[1,0],[0,1]]

pos=[0,0]
player=Player(0,0)

map=[]

def getLevel(Level):
        #if Level=="save":
        #    file="save.txt"
        #else:
        file="levels\level"+str(Level)+".txt"
        global first, spikes, flames, snakes, enemies, pos, cam, map, player, boxes, buttons, switches
        spikes=[]
        flames=[]
        snakes=[]
        enemies=[]
        boxes=[]
        buttons=[]
        switches=[]
        pos=[0,0]
        cam=[0,0,15,15]
        player=Player(0,0)
        map=[]
        fill=""
        for x in range(cam[2]):
            fill+="/"
        maxmap=0
		
        f = open(file, "r")
        l = f.readlines()
        i=0
        map=[]
        for x in l:
            i+=1
            if i!=len(l):
                x=x[:-1]
            #print(x)
            x=wrap(x+fill,1)
            map.append(x)
            if maxmap <= len(x):
                maxmap=len(x)
        fill2=[]
        for x in range(maxmap):
            fill2.append("/")
        for x in range(cam[3]):
            map.append(fill2)
        #print(map)
        for y in range(len(map)):
            for x in range(len(map[y])):
                if map[y][x] == '^' or map[y][x] == ',':
                    spikes.append(Spike(x,y,0,3))
                if map[y][x] == '^' or map[y][x] == '"':
                    spikes.append(Spike(x,y,0,7))
                elif map[y][x] == '=':
                    flameDir=0
                    if map[y][x-1] == "#":
                        flameDir=1
                    elif map[y][x+1] == "#":
                        flameDir=-1
                    else:
                        continue
                    flames.append(Flamethrower(x,y,0,flameDir,3,7))
                elif map[y][x] == '$':
                    body=[Segment(x,y)]
                    for b in body:
                        for n in neighbors:
                            if any(part.x==n[0]+b.x and part.y==n[1]+b.y for part in body):
                                continue
                            if map[n[1]+b.y][n[0]+b.x] == "%":
                                body.append(Segment(n[0]+b.x,n[1]+b.y))
                    body.pop(0)
                    snakes.append(Snake(x,y,body))
                elif map[y][x] == 'E':
                    enemies.append(Enemy(x,y))
                #if map[y][x] == '/':
                    #map[y][x]=" "
                elif map[y][x] == '&':
                    boxes.append(Box(x,y))
                elif map[y][x] == 'p':
                    wires=[[x,y]]
                    doors=[]
                    for w in wires:
                        for n in neighbors:
                            if any(wire[0]==n[0]+w[0] and wire[1]==n[1]+w[1] for wire in wires):
                                continue
                            if map[n[1]+w[1]][n[0]+w[0]] == "b":
                                wires.append([n[0]+w[0],n[1]+w[1]])
                            if map[n[1]+w[1]][n[0]+w[0]] == "D":
                                doors=[Door(n[0]+w[0],n[1]+w[1])]
                                for d in doors:
                                    for m in neighbors:
                                        if any(door.x==m[0]+d.x and door.y==m[1]+d.y for door in doors):
                                            continue
                                        if map[m[1]+d.y][m[0]+d.x] == "D":
                                            doors.append(Door(m[0]+d.x,m[1]+d.y))
                    #out.append(x)
                    #out.append(y)
                    #out.append(door)
                    wires.pop(0)
                    buttons.append(Button(x,y,doors,wires))
                elif map[y][x] == 'S':
                    wires=[[x,y]]
                    doors=[]
                    for w in wires:
                        for n in neighbors:
                            if any(wire[0]==n[0]+w[0] and wire[1]==n[1]+w[1] for wire in wires):
                                continue
                            if map[n[1]+w[1]][n[0]+w[0]] == "b":
                                wires.append([n[0]+w[0],n[1]+w[1]])
                            if map[n[1]+w[1]][n[0]+w[0]] == "D":
                                doors=[Door(n[0]+w[0],n[1]+w[1])]
                                for d in doors:
                                    for m in neighbors:
                                        if any(door.x==m[0]+d.x and door.y==m[1]+d.y for door in doors):
                                            continue
                                        if map[m[1]+d.y][m[0]+d.x] == "D":
                                            doors.append(Door(m[0]+d.x,m[1]+d.y))
                                        
                    #out.append(x)
                    #out.append(y)
                    #out.append(door)
                    wires.pop(0)
                    switches.append(Switch(x,y,doors,wires))

                elif map[y][x] == '@':
                    if map[y+1][x] == "#":
                        map[y][x]="_"
                    else:
                        map[y][x]="."
                    pos=[x,y]
                    player.x=x
                    player.y=y
                elif map[y][x] == '-' or map[y][x] == '~' or map[y][x] == ';':
                    if map[y+1][x] == "#":
                        map[y][x]="_"
                    else:
                        map[y][x]="."
        cam[0]=player.x-int(cam[2]/2)
        cam[1]=player.y-int(cam[3]/2) 
        save=[]
        map[player.y][player.x]="@"
        for ys in range(len(map)-cam[3]):
            line=""
            for xs in range(len(map[ys])-cam[2]):
                line+=map[ys][xs]+" "
                save.append(line)
            s=open("save.txt", "w")
            for x in save:
                #print(x)
                s.write(x+"\n")
        s.close()
getLevel(level)

			
#print(map)
#print(len(map))
loops=0
dir=1
      
move=[0,0]
delay=0
looped=0
savePoint=[0,0]
out=[]

while True:
    delay+=1
    if delay>= 10 and move[0]!=0 or delay>= 10 and move[1]!=0 or first==True:
        out=[]
        #out.append(level)
        #out.append(type(level))
        saved=False
        first=False
        looped+=1
        os.system("cls")
        for s in spikes:
            if s.time == 0:
                map[s.y][s.x]="^"
                s.state = 1
            elif s.time == 2:
                map[s.y][s.x]=","
                s.state = 0
            s.time+=1
            if s.time > s.maxTime:
                s.time = 0

        for f in flames:
            for d in range(f.range):
                if f.time >= 0 and f.time <= 3:
                    if (d+(f.time%2))%2==0:
                        map[f.y][f.x+((d+1)*f.facing)]="~"
                    else:
                        map[f.y][f.x+((d+1)*f.facing)]="-"
                elif f.time==4:
                    map[f.y][f.x+((d+1)*f.facing)]="."
                elif f.time==7:
                    map[f.y][f.x+(1*f.facing)]=";"
            f.time+=1
            if f.time > f.maxTime:
                f.time = 0
        
        for n in snakes:
            forward=[n.x-n.segments[0].x,n.y-n.segments[0].y]
            left=[forward[1]*-1,forward[0]]
            right=[forward[1],forward[0]*-1]
            
            if map[n.y+forward[1]][n.x+forward[0]] == ":":
                nextPos=[n.x+forward[0],n.y+forward[1]]
            elif map[n.y+left[1]][n.x+left[0]]:
                nextPos=[n.x+left[0],n.y+left[1]]
            elif map[n.y+right[1]][n.x+right[0]]:
                nextPos=[n.x+right[0],n.y+right[1]]

            map[n.segments[-1].y][n.segments[-1].x]=":"
            n.segments.pop(-1)
        
            map[n.y][n.x]="%"
            n.segments.insert(0,Segment(n.x,n.y))
            n.x=nextPos[0]
            n.y=nextPos[1]
            map[n.y][n.x]="$"
            
        for enemy in enemies:
            distx=player.x-enemy.x
            disty=player.y-enemy.y
            #out.append(distx)
            #out.append(disty)
            target=[0,0]

            if abs(distx) <= 6 and abs(disty) <= 6:
                scentMap=[]
                neighbors=[[-1,0],[0,-1],[1,0],[0,1]]
                for y in range(13):
                    row=[]
                    for x in range(13):
                        row.append(26)
                    scentMap.append(row)
                    
                searching=[]
                for y in range(13):
                    row=[]
                    for x in range(13):
                        row.append(False)
                    searching.append(row)

                searching[6][6]=True

                scentMap[6][6]=0
                nodes=[[6,6]]

                for n in nodes:
                    for x in neighbors:
                        nx=n[0]+x[0]
                        ny=n[1]+x[1]
                        hx=n[0]
                        hy=n[1]
                        worldy=player.y+ny-6
                        worldx=player.x+nx-6
                        if ny < 0 or ny >= 13:
                            continue
                        if nx < 0 or nx >= 13:
                            continue
                        here=scentMap[hy][hx]
                        if searching[ny][nx] == False:
                            state=map[worldy][worldx]
                            if state=="#":
                                continue
                            if scentMap[ny][nx] >= here:
                                scentMap[ny][nx]=here+1
                                nodes.append([nx,ny])
                            searching[ny][nx]=True
                            if state=="E":
                                nodes=[]
                                lowest=26
                                target=[0,0]
                                values=[]
                                
                                for y in neighbors:   
                                    ex=nx+y[0]
                                    ey=ny+y[1]
                                    if ey < 0 or ey >= 13:
                                        continue
                                    if ex < 0 or ex >= 13:
                                        continue
                                    values.append([y[0],y[1],scentMap[ey][ex]])

                                minV=24
                                for m in values:
                                    if m[2] < minV:
                                        minV=m[2]
                                        
                                closest=[v for v in values if v[2]==minV]
                                if len(closest)>=1:
                                    choice=random.choice(closest)
                                    target=[choice[0],choice[1]]
##                                for y in neighbors:
##                                    ex=nx+y[0]
##                                    ey=ny+y[1]
##                                    #out.append(str(ex)+" "+str(ey))
##                                    if ey < 0 or ey >= 13:
##                                        continue
##                                    if ex < 0 or ex >= 13:
##                                        continue
##
##                                    if scentMap[ey][ex] <= lowest:
##                                        lowest=scentMap[ey][ex]
##                                        target=[y[0],y[1]]
                                break
                #for p in scentMap:
                    #out.append(p)
                #for p in searching:
                    #out.append(p)
            map[enemy.y][enemy.x]=enemy.here
            enemy.x+=target[0]
            enemy.y+=target[1]
            enemy.here=map[enemy.y][enemy.x]
            map[enemy.y][enemy.x]="E"
                
        delay=0
        if map[player.y][player.x] == '@':
            if map[player.y + 1][player.x] == "#":
                map[player.y][player.x] = "_"
            else:
                map[player.y][player.x] = "."
        #if dir==1 and pos[1]>=len(map)-1:
        #  dir=-1
        #elif dir==-1 and pos[1]==0:
        #  dir=1
        #pos[1]+=dir
        if map[player.y+move[1]][player.x+move[0]] == "&":
            for b in boxes:
                if b.x == player.x+move[0] and b.y == player.y+move[1]:
                    tileB=map[b.y+move[1]][b.x+move[0]]
                    if not tileB == "#" and not tileB == "=" and not tileB == "T" and not tileB == "/" and not tileB == "&":
                        map[b.y][b.x] = b.here
                        b.x+=move[0]
                        b.y+=move[1]
                        b.here=map[b.y][b.x]
                        map[b.y][b.x]="&"
                    else:
                        move=[0,0]
                        
        for b in buttons:
            if any(box.x == b.x and box.y == b.y for box in boxes) or b.x == player.x+move[0] and b.y == player.y+move[1]:
                b.state=True
                for door in b.doors:
                    map[door.y][door.x]="o"
                for w in b.wires:
                    map[w[1]][w[0]]="o"
            else:
                b.state=False
                for door in b.doors:
                    map[door.y][door.x]="D"
                for w in b.wires:
                    map[w[1]][w[0]]="b"
                    
        for s in switches:
            if any(box.x == s.x and box.y == s.y for box in boxes) or s.x == player.x+move[0] and s.y == player.y+move[1]:
                s.state=True
                for door in s.doors:
                    map[door.y][door.x]="o"
                map[s.y][s.x]="s"
                for w in s.wires:
                    map[w[1]][w[0]]="o"
                    
        tileH = map[player.y][player.x+move[0]]
        if not tileH == "#" and not tileH == "=" and not tileH == "T" and not tileH == "/" and not tileH == "&":
            player.x += move[0]
        tileV = map[player.y+move[1]][player.x]
        if not tileV == "#" and not tileV == "=" and not tileV == "T" and not tileV == "/" and not tileV == "&":
            player.y += move[1]
        cam[0]=player.x-int(cam[2]/2)
        cam[1]=player.y-int(cam[3]/2)
        tile = map[player.y][player.x]
        if tile == "^" or tile == "~" or tile == "-" or tile == "$" or tile == "%" or tile == "E":
            os.system("cls")
            title=getTitle("gameOver")
            print(title)
            input("")
            os.system("cls")
            getLevel(level)
        elif tile == "*":
            os.system("cls")
            title=getTitle("nextLevel")
            print(title)
            input("")    
            os.system("cls")
            level=int(level)
            level+=1
            getLevel(level)
        #elif tile=="&":
            
            #if tile == "R":
            #    if pos[0] == savePos[0] and abs(player.y-savePos[1]) < 5:
            #        false=False
            #    elif pos[1] == savePos[1] and abs(pos[0]-savePos[0]) < 5:
            #        false=False
            #    else:
            #        savePos=pos
            #        save=[]
            #        saved=True
            #        map[pos[1]][pos[0]]="@"
            #        for ys in range(len(map)-cam[3]):
            #            line=""
            #            for xs in range(len(map[ys])-cam[2]):
            #                line+=map[ys][xs]+" "
            #            save.append(line)
            #        s=open("save.txt", "w")
            #        for x in save:
            #            #print(x)
            #            s.write(x+"\n")
            #            s.close()
            #            #os.system("start "+"map2.txt")
        signPos=[0,0]
        if map[player.y+1][player.x] == "T":
            signPos=[player.y+1,player.x]
        elif map[player.y][player.x+1] == "T":
            signPos=[player.y,player.x+1]
        elif map[player.y-1][player.x] == "T":
            signPos=[player.y-1,player.x]
        elif map[player.y][player.x-1] == "T":
            signPos=[player.y,player.x-1]
        elif map[player.y][player.x] == "T":
            signPos=[player.y,player.x]
        if signPos!=[0,0]:
            textFile="levels\\text\\level"+str(level)+"-text-"+str(signPos[1])+"-"+str(signPos[0])+".txt"
            sign = open(textFile, "r")
            signText = sign.read()
        else:
            signText=""
        move=[0,0]
        reset=map[player.y][player.x]
        map[player.y][player.x]="@"
        pm=[]
        if len(map)-cam[1]-1 < cam[3]:
            height=len(map)
        else:
            height=cam[3]
        for iy in range(height):
            y=map[iy+cam[1]]
            py=""
            if len(y)-cam[0]-1 < cam[2]:
                width=len(y)-cam[0]-1
            else:
                width=cam[2]
            for ix in range(width):
                x=y[ix+cam[0]]
                if x=="/":
                    py+="  "
                elif x==":" or x=="R" or x=="." or x==">":
                    py+=colors.gray+". "
                elif x=="$":
                    py+=colors.green+"S "
                elif x=="%":
                    py+=colors.green+"s "
                elif x=="#":
                    py+=colors.yellow+"# "
                elif x==",":
                    py+=colors.gray+", "
                elif x=="^":
                    py+=colors.red+"^ "
                elif x=="\"":
                    py+=colors.red+"^ "
                elif x=="*":
                    py+=colors.purple+"* "
                elif x=="-":
                    py+=colors.yellow+"- "
                elif x=="~":
                    py+=colors.red+"~ "
                elif x=="E":
                    py+=colors.red+"E "
                elif x=="=":
                    py+=colors.gray+"= "
                elif x==";":
                    py+=colors.yellow+"; "
                elif x=="b":
                    py+=colors.blue+". "
                elif x=="o":
                    py+=colors.yellow+". "
                elif x=="s":
                    py+=colors.yellow+"s "
                else:
                    py+=colors.white+x+" "
                
            pm.append(py)
            #click.clear()
        screen=""
        #print("  _______________________________")
        screen+=colors.white+"  "+("_"*(cam[2]*2+1))+"\n"
        for p in pm:
            #print(" | "+p+"| ") 
            screen+=f'{colors.white+" | "+p: <{cam[2]*2+13}}'+colors.white+"| \n"
        #print(" |_______________________________|")
        screen+=" |"+("_"*(cam[2]*2+1))+"|" 
        for x in out:
            print(x)
        print(screen)
        for x in signText.split("\n"):
            width=(cam[2]*2+5)
            print(f'{x: ^{width}}')
        if saved==True:
            print("Game Saved")
        map[player.y][player.x]=reset

    if delay>= 10 and keyboard.is_pressed("w"):
        move[1]=-1
    if delay>= 10 and keyboard.is_pressed("s"):
        move[1]=1
    if delay>= 10 and keyboard.is_pressed("a"):
        move[0]=-1
    if delay>= 10 and keyboard.is_pressed("d"):
        move[0]=1
    if delay>= 10 and keyboard.is_pressed("space"):
        attacking=True
    if delay>= 10 and keyboard.is_pressed("esc"):
##        save=[]
##        map[player.y][player.x]="@"
##        for ys in range(len(map)-cam[3]):
##            line=""
##            for xs in range(len(map[ys])-cam[2]):
##                line+=map[ys][xs]+" "
##            save.append(line)
##        s=open("map2.txt", "w")
##        for x in save:
##            #print(x)
##            s.write(x+"\n")
##        s.close()
##        #os.system("start "+"map2.txt")
        exit()
        
    time.sleep(0.01)
    loops+=1
            

