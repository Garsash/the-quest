from rcolors import colors
from mathLib import Vector
from objects.player import Player
colorise=colors.colorise

##        #find distance from player
##        distx=player.x-enemy.x
##        disty=player.y-enemy.y
##        target=[0,0]
##
##        if abs(distx) <= 6 and abs(disty) <= 6:
##            #create scent map
##            scentMap=[]
##            for y in range(13):
##                row=[]
##                for x in range(13):
##                    row.append(26)
##                scentMap.append(row)
##
##            #create searching map
##            searching=[]
##            for y in range(13):
##                row=[]
##                for x in range(13):
##                    row.append(False)
##                searching.append(row)
##
##            #set player location
##            searching[6][6]=True
##            scentMap[6][6]=0
##            nodes=[[6,6]]
##
##            #loop through nodes
##            for node in nodes:
##                #look at neighbors
##                for neighbor in neighbors:
##                    #variable set up
##                    neighborx=node[0]+neighbor[0] #nx
##                    neighbory=node[1]+neighbor[1] #ny
##                    nodex=node[0] #hx
##                    nodey=node[1] #hy
##                    worldy=player.y+neighbory-6
##                    worldx=player.x+neighborx-6
##
##                    #if inside map
##                    if neighbory < 0 or neighbory >= 13:
##                        continue
##                    if neighborx < 0 or neighborx >= 13:
##                        continue
##
##                    here=scentMap[nodey][nodex]
##                    #if not searched already
##                    if searching[neighbory][neighborx] == False:
##                        #is there a wall
##                        state=map[worldy][worldx]
##                        if state in wallTiles or state in deathTiles and state != "E":
##                            continue
##
##                        #get smallest scent
##                        if scentMap[neighbory][neighborx] >= here:
##                            scentMap[neighbory][neighborx]=here+1
##                            nodes.append([neighborx,neighbory])
##                        searching[neighbory][neighborx]=True
##
##                        #found enemy
##                        if state=="E" and worldx==enemy.x and worldy==enemy.y:
##                            #out.append([worldx,worldy])
##                            #Loc=[worldx,worldy]
##                            #out.append("enemy pos "+str(Loc))
##                            #if Loc in foundEnemies:
##                            #    continue
##                            nodes=[]
##                            lowest=26
##                            target=[0,0]
##                            values=[]
##
##                            #look at neighbors
##                            for Neighbor in neighbors:   
##                                enemyx=neighborx+Neighbor[0]
##                                enemyy=neighbory+Neighbor[1]
##                                if enemyy < 0 or enemyy >= 13:
##                                    continue
##                                if enemyx < 0 or enemyx >= 13:
##                                    continue
##                                #find values
##                                if map[player.y+enemyy-6][player.x+enemyx-6] == "E":
##                                    continue
##                                values.append([Neighbor[0],Neighbor[1],scentMap[enemyy][enemyx]])
##
##                            #get smallest values
##                            minV=24
##                            for min in values:
##                                if min[2] < minV:
##                                    minV=min[2]
##
##                            #pick random closest direction
##                            closest=[value for value in values if value[2]==minV]
##                            if len(closest)>=1:
##                                choice=random.choice(closest)
##                                target=[choice[0],choice[1]]
##                            break
##        #move enemy
##        map[enemy.y][enemy.x]=enemy.here
##        enemy.x+=target[0]
##        enemy.y+=target[1]
##        enemy.here=map[enemy.y][enemy.x]
##        map[enemy.y][enemy.x]="E"

class Scent():
    def __init__(self,scent,searched=False):
        self.scent=scent
        self.searched=searched

class Enemy():
    instantiationTiles=[]

    #@staticmethod
    #def instantiationTiles():
    #    return ["^"]

    @classmethod
    def create(cls,x,y,level):
        enemy=Enemy(x,y,)
        level.createObject(enemy)

    def __init__(self,x,y,distance=13,tile="",layer=0):
        self.x = x
        self.y = y
        self.tile=tile
        self.layer=layer
        self.distance=distance
        self.damage=True
    
    def tick(self,level, **kwargs):
        scentMap=[[Scent(self.distance*2,False) for x in range(self.distance)]for x in range(self.distance)]
        center=int(self.distance/2)
        searching=[Vector(center,center)]
        scentMap[center][center].scent=0
        scentMap[center][center].searched=True

        for position in searching:
            for neighbor in Vector.neighbors():
                mapSpaceNeighborCoords=position+neighbor
                for obj in level.objects:
                    if type(obj)==Player:
                        player=obj
                levelSpaceNeighborCoords=Vector(player.x,player.y)+mapSpaceNeighborCoords-Vector(center,center)

                #skip if outside scentMap
                if mapSpaceNeighborCoords.x < 0 or mapSpaceNeighborCoords >= self.distance or mapSpaceNeighborCoords.y < 0 or mapSpaceNeighborCoords.y >= self.distance:
                    continue
                
                scentHere=scentMap[position.y][position.x]
                neighborScent=scentMap[mapSpaceNeighborCoords.y][mapSpaceNeighborCoords.x]
                if neighborScent.searched==False:
                    tile=level.getTile(levelSpaceNeighborCoords.x,levelSpaceNeighborCoords.y)
                    if tile in level.wallTiles or any(x.damage==True and x.x==levelSpaceNeighborCoords.x and x.y==levelSpaceNeighborCoords.y and type(x)!=Enemy for x in level.objects):
                        if neighborScent.scent >= scentHere.scent:
                            neighborScent.scent=scentHere.scent+1
                            searching.append(mapSpaceNeighborCoords)
                        neighborScent.searched=True

                        if self.x==levelSpaceNeighborCoords.x and self.y==levelSpaceNeighborCoords.y:
                            searching=[]
                            lowestScent=self.distance
                            target=Vector(0,0)
                            possibleMoves=[]

                            for neighbor in Vector.neighbors():
                                mapSpaceMove=neighbor+mapSpaceNeighborCoords
                                levelSpaceMove=Vector(player.x,player.y)+mapSpaceMove-Vector(center,center)
                                if mapSpaceMove.x < 0 or mapSpaceMove.y >= self.distance or mapSpaceMove.x < 0 or mapSpaceMove.y >= self.distance:
                                    continue
                                if any(type(x)==Enemy and x.damage==True and x.x==levelSpaceMove.x and x.y==levelSpaceMove.y for x in level.objects):
                                    




    
    def draw(self, **kwargs):
        return self.tile