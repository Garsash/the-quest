class Spike():
    instantiationTiles=["^",",","\""]

    #@staticmethod
    #def instantiationTiles():
    #    return ["^"]

    @classmethod
    def create(cls,x,y,level):
        tile=level.getTile(x,y)  

        if tile == '^' or tile == ',':
            spike=Spike(x,y,0,3)
            level.createObject(spike)
        if tile == '"':
            spike=Spike(x,y,0,7)
            level.createObject(spike)
        level.setTile(x,y,".")

    def __init__(self,xPos,yPos,State,Timer):
        self.x = xPos
        self.y = yPos
        self.state = State
        self.maxTime = Timer
        self.time = 0
    
    def tick(self):
        #up
        if self.time == 0:
            map[self.y][self.x]="^"
            self.state = 1
        #down
        elif self.time == 2:
            map[self.y][self.x]=","
            self.state = 0
        self.time+=1
        #reset
        if self.time > self.maxTime:
            self.time = 0